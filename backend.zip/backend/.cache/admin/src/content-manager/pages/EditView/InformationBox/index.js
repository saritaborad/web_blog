import { InformationBoxCE } from './InformationBoxCE';

export default InformationBoxCE;
