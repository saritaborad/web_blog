// Overwritten in EE
export default () => null;
