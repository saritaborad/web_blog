export default function useLocalesProvider() {
  return {
    changeLocale() {},
    localeNames: { en: 'English' },
    messages: ['test'],
  };
}
