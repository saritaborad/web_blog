import customGlobalLinks from 'ee_else_ce/hooks/useSettingsMenu/utils/customGlobalLinks';
import defaultGlobalLinks from './defaultGlobalLinks';

export default [...defaultGlobalLinks, ...customGlobalLinks];
