const useLicenseLimitNotification = () => {
  return null;
};

export default useLicenseLimitNotification;
