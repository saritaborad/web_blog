export default function () {
  return {
    logos: {
      auth: { custom: 'customAuthLogo.png', default: 'defaultAuthLogo.png' },
    },
  };
}
